import React from 'react'
import { Container } from '../../globalStyles'

const Home = () => {
  return (
    <Container>

    </Container>
  )
}

export default Home