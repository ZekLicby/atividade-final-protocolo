export const theme = {
    background: '#690013',
    gray: '#A6A6A6',
    darkGray: '#D9D9D9',
    dakerGray: '#929292',
    green: '#128232',
    darkGreen: '#06540D',
    blue: '#209EBA',
    brow: '#8B642A',
}